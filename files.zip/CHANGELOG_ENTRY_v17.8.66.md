<!-- v17.8.66 -- SOUNDNESS: section Z item 7 (b: shared atomic incumbent, c: bound-sorted root
     partitioning) taken from "fuzz-verified off-tree but not yet the full 12-regime harness"
     (v17.8.61 status) to component-isolated + full-pipeline TESTED. No production code changed
     -- this is a harness-only entry.

     WHY A NEW HARNESS INSTEAD OF REUSING solver_bound_tests_v2.js: that harness targets a
     different bug family (dacVec's collision-fix branch, assignMaxSumNode, spMaxFreeBox) and its
     "component in isolation, generator forced to hit the real precondition" SHAPE is the
     reusable part, not its content -- item 7 has no dacVec/h2NodeBound involvement at all. Five
     new files apply that same shape to item 7's actual surface (the CAS-max publish loop, the
     root-candidate sort, and the rootAllow+sharedFloor plumbing), per this session's brief that
     DAC passed its original aggregate fuzz and only failed once someone checked the individual
     component whose precondition that fuzz never actually forced -- the same trap a generic
     "run the solver on random drafts with a floor sometimes set" fuzzer would fall into here,
     since a random floor is unlikely to land exactly where it would actually bind.

     FILES (in /mnt/user-data/outputs/section_z_item7_harness/, six total, self-contained --
     unlike the appendix's placeholder prod_solver.js, this one is a REAL verbatim extraction of
     scoreXI/solveBest from this exact file version, not a paste-it-yourself stub):
       prod_solver.js              -- scoreXI + solveBest, byte-identical extraction (lines
                                       7694-8356 of this file), require()-able.
       indep_brute.js              -- unchanged from the appendix (independent odometer oracle,
                                       shares no code with the solver except injected scoreXI).
       fuzz_gen.js                 -- unchanged from the appendix's 11 synthetic regimes
                                       (realDB regime dropped -- no playerDB.json dependency
                                       needed for this harness's purpose).
       test_A_sort_isolated.js     -- item 7c's root-candidate sort, alone: is it a lossless
                                       permutation, is it correctly ordered. (The "lossless"
                                       check exists because a lossy partition step could shrink
                                       the search space in a way an end-to-end score comparison
                                       would never catch if the dropped card wasn't optimal
                                       anyway -- structurally the same blind spot v1's DAC
                                       generator had.)
       test_B_floor_forced.js      -- sharedFloor forced to the three boundary values that
                                       actually exercise item 7b's logic (floor == true optimum
                                       exactly; floor == true optimum + 1, i.e. unreachable;
                                       floor seeded from a real sibling partition's true best
                                       while this worker's own rootAllow is restricted to a
                                       provably worse slice) instead of hoping a random floor
                                       lands somewhere that binds.
       test_C_cas_concurrency.js   -- the exact CAS-max retry loop (index.html:8433-8434),
                                       hammered by REAL OS threads (worker_threads) racing on one
                                       SharedArrayBuffer, not a single-threaded simulation --
                                       checks for lost updates.
       test_D_multiworker_e2e.js   -- closest in-Node replica of the real browser path: real
                                       worker_threads each running the actual extracted
                                       solveBest on a disjoint root partition, one real shared
                                       floor, merged exactly like _mergeWorkerResults, checked
                                       against indep_brute.js. Half the instances are rating-
                                       skewed on purpose so the floor is likely to actually bind
                                       rather than sit at -1 for the whole run.
       test_E_absent_regression.js -- sharedFloor/rootSlotIdx omitted (the untouched default
                                       path every non-opted-in caller still uses) vs indep_brute,
                                       across all 11 synthetic regimes.
       run_all.js                  -- runs all five in sequence.
     HOW TO RUN: node run_all.js  (or any test_*.js individually; each is directly executable and
     prints PASS/FAIL plus a numeric summary). No dependencies beyond a Node version with
     SharedArrayBuffer/Atomics/worker_threads (built in since Node 12ish; verified here on v22).

     RESULTS (this session, single run each -- reproducible, seeds are fixed):
       A) root-candidate sort, isolated:            2,000 checked / 0 lossy-permutation / 0
                                                      ordering failures.                    PASS
       B) sharedFloor, forced boundary values:       2,618 checked (of 4,000 drafts attempted --
                                                      the rest skipped as infeasible or too large
                                                      for the brute oracle's combos budget) / 0
                                                      dropped-tie / 0 overshoot / 0 fabrication /
                                                      0 split-worker-merge failures.          PASS
       C) CAS-max publish loop, real OS threads:     12 rounds, 2-7 real concurrent threads each,
                                                      4,000 attempts/thread / 0 lost updates.
                                                                                              PASS
       D) full multi-worker pipeline, real threads,
          merged vs independent brute force:         54 genuine multi-thread runs (2-4 real
                                                      worker_threads each, actual solveBest, one
                                                      real shared floor) / floor actually bound
                                                      (ended >=0) in 51/54 / 0 merged-answer
                                                      mismatches / 0 illegal or misscored bestXIs.
                                                                                              PASS
       E) sharedFloor-absent regression, all
          11 synthetic regimes:                      2,283 checked / 0 mismatches, broken out
                                                      per-regime in the run log (every regime
                                                      individually clean, not just the aggregate).
                                                                                              PASS

     ONE BUG FOUND AND FIXED -- IN THE HARNESS, NOT THE SOLVER: test D's first draft applied its
     deliberate rating-skew (to make the floor likely to bind) to a COPY of the draft made after
     the brute-force oracle had already scored the unskewed original, so the oracle and the
     solver were silently being compared on two different instances. Every "mismatch" in that
     run was the solver scoring HIGHER than the (wrong) oracle by a small, plausible-looking
     margin (5 mismatches on the +15 skew, all solver > brute) -- worth recording because that
     shape (a consistent one-directional gap that looks like it could be a real bound-tightness
     bug) is exactly the kind of false signal a hasty read would misattribute to solveBest itself
     rather than to a harness ordering bug. Fixed by applying the skew before the oracle runs, on
     the same object both sides then score; re-run came back clean (see D above). Recorded here
     per this file's own G-section discipline (write the entry after the change is verified, and
     don't bury a harness bug just because it wasn't in the shipped code).

     WHAT THIS DOES AND DOES NOT ESTABLISH: A-E clear the specific pending-harness flag v17.8.61
     left on item 7b/7c. They do not replace section H's own full twelve-regime harness + real
     fingerprint fixtures (browser-run, real playerDB, real formations, includes the realDB
     regime) -- that box is still open and should be checked off separately per F.2/Q.2 discipline
     before this is called fully release-final. What A-E specifically add over the v17.8.61
     "367 random small drafts + 734 two-worker runs" fuzz claim: (1) an isolated, non-inferred
     check on the sort component itself (A); (2) boundary values chosen to force the precondition
     rather than sampled randomly (B); (3) REAL OS-thread concurrency on the actual CAS code,
     not a simulated interleaving (C); (4) a genuine multi-thread solveBest pipeline, not a
     single-thread stand-in for one (D); (5) a full per-regime regression sweep on the untouched
     default path (E).
-->
