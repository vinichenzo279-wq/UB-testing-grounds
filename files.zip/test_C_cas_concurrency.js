'use strict';
// ==========================================================================================
// TEST C) The CAS-max publish loop, under REAL concurrency.
// Verbatim copy of the retry loop at index.html:8433-8434 (the exact code every dfs() leaf
// runs to publish a new incumbent). Tested here with actual OS threads (worker_threads), not a
// single-threaded simulation -- a simulated interleaving can accidentally never exercise the
// real race window, the same way v1's DAC generator never exercised its collision branch. This
// spawns real threads hammering ONE shared Int32Array simultaneously and checks the final value
// is the true max of every value any thread attempted, with zero lost updates.
// ==========================================================================================
const { Worker, isMainThread, workerData, parentPort } = require('worker_threads');

const WORKER_CODE = `
const { parentPort, workerData } = require('worker_threads');
const { sab, attemptsPerThread, seed } = workerData;
const floor = new Int32Array(sab);
let s = seed >>> 0;
function rnd(){ s = (s*1664525+1013904223)>>>0; return s; }
const attempted = [];
for(let i=0;i<attemptsPerThread;i++){
  const v = rnd() % 1000000; // candidate "score" this thread found
  attempted.push(v);
  // ===== verbatim retry loop under test =====
  let __cur = Atomics.load(floor, 0);
  while (v > __cur) { const __prev = Atomics.compareExchange(floor, 0, __cur, v); if (__prev === __cur) break; __cur = __prev; }
  // ===========================================
}
parentPort.postMessage(attempted);
`;

async function runOnce(numThreads, attemptsPerThread, seedBase){
  const sab = new SharedArrayBuffer(4);
  const floor = new Int32Array(sab);
  Atomics.store(floor, 0, -1);

  const fs = require('fs');
  const path = require('os').tmpdir() + '/_cas_worker_' + process.pid + '_' + Math.random().toString(36).slice(2) + '.js';
  fs.writeFileSync(path, WORKER_CODE);

  const promises = [];
  for(let i=0;i<numThreads;i++){
    promises.push(new Promise((resolve,reject)=>{
      const w = new Worker(path, { workerData: { sab, attemptsPerThread, seed: seedBase+i*7919 } });
      w.on('message', resolve);
      w.on('error', reject);
    }));
  }
  const allAttempted = (await Promise.all(promises)).flat();
  fs.unlinkSync(path);

  const finalVal = Atomics.load(floor, 0);
  const trueMax = Math.max(-1, ...allAttempted);
  return { finalVal, trueMax, ok: finalVal === trueMax };
}

async function main(){
  console.log('=== C) sharedFloor CAS-max publish loop, real OS-thread concurrency ===');
  let rounds=0, fails=0;
  const NUM_ROUNDS = 12;
  for(let r=0;r<NUM_ROUNDS;r++){
    const numThreads = 2 + (r % 6); // 2..7 real threads
    const attemptsPerThread = 4000;
    const res = await runOnce(numThreads, attemptsPerThread, r*104729+1);
    rounds++;
    if(!res.ok){
      fails++;
      console.log(`  round ${r} (${numThreads} threads): LOST UPDATE -- final=${res.finalVal} true max=${res.trueMax}`);
    }
  }
  console.log(`rounds: ${rounds}  lost-update failures: ${fails} (expect 0)`);
  console.log(fails===0 ? 'PASS' : 'FAIL');
  if(fails>0) process.exitCode=1;
}

if(isMainThread) main();
