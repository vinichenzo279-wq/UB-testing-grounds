'use strict';
function mulberry32(seed){return function(){seed|=0;seed=(seed+0x6D2B79F5)|0;let t=Math.imul(seed^(seed>>>15),1|seed);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};}

const SYN_FORMS = [
  {name:'S-5',   slots:['GK','CB','CM','ST','LW']},
  {name:'S-6',   slots:['GK','CB','CB','CM','ST','ST']},
  {name:'S-7',   slots:['GK','CB','CB','CB','CM','CM','ST']},
  {name:'S-8',   slots:['GK','RB','CB','LB','CDM','CAM','RW','ST']},
  {name:'S-9',   slots:['GK','CB','CB','CM','CM','CM','LW','RW','ST']},
];
const PREM='England Premier League';
const SYN_LEAGUES=['La Liga','Bundesliga','Serie A','Ligue 1'];
const SYN_NATIONS=['Arg','Bra','Fra','Eng','Ger','Spa','Por','Ned','Jap','Nig','Uru','Cro'];
const SYN_CLUBS=['Alpha','Bravo','Cobra','Delta','Echo','Foxtrot','Golf','Hotel','India','Juliet'];

function pick(rng,a){return a[Math.floor(rng()*a.length)];}
function rnd(rng,a,b){return Math.floor(rng()*(b-a+1))+a;}

function makeCard(uid, rng, dials){
  const r = dials.rating(rng);
  const tRoll = rng();
  const type = tRoll < dials.iconP ? 'icon' : (tRoll < dials.iconP + dials.heroP ? 'hero' : 'normal');
  const nation = pick(rng, dials.nations);
  let league, club = null;
  if (type === 'normal') { league = PREM; club = pick(rng, dials.clubs); }
  else if (type === 'hero') { league = rng() < dials.premHeroP ? PREM : pick(rng, dials.heroLeagues); }
  else league = 'Icons';
  return { id: uid, hold: null, label: 'F' + uid, type, rating: r, nation, league, club, pos: [] };
}

function genSynthetic(seed, regime){
  const rng = mulberry32(seed);
  const dials = {
    rating: r => rnd(r, 75, 96),
    iconP: 0.12, heroP: 0.2, premHeroP: 0.35,
    nations: SYN_NATIONS.slice(), clubs: SYN_CLUBS.slice(), heroLeagues: SYN_LEAGUES.slice(),
    minPer: 2, maxPer: 3, multiPosP: 0.2, holdP: 0.12, forms: SYN_FORMS
  };
  switch (regime) {
    case 'ties':        dials.rating = r => pick(r, [88,88,88,90,90,92]); break;
    case 'narrow':      dials.rating = r => rnd(r, 90, 92); break;
    case 'wide':        dials.rating = r => rnd(r, 47, 99); break;
    case 'monoNation':  dials.nations = SYN_NATIONS.slice(0, rnd(rng,1,2)); break;
    case 'polyMax':     dials.nations = null; break;
    case 'iconHeavy':   dials.iconP = 0.7; dials.heroP = 0.15; break;
    case 'heroLeagues': dials.heroP = 0.6; dials.iconP = 0.05; dials.premHeroP = rng()<0.5?1.0:0.0; break;
    case 'holds':       dials.holdP = 0.45; break;
    case 'multiPos':    dials.multiPosP = 0.6; break;
    case 'dupSlots':    dials.forms = SYN_FORMS.filter(f=>/S-6|S-7|S-9/.test(f.name)); break;
    case 'kitchenSink':
      dials.rating = r => (r()<0.3?rnd(r,88,88):rnd(r,60,99));
      dials.iconP = rng()*0.5; dials.heroP = rng()*0.5*(1-dials.iconP);
      dials.nations = SYN_NATIONS.slice(0, rnd(rng,1,SYN_NATIONS.length));
      dials.clubs = SYN_CLUBS.slice(0, rnd(rng,1,SYN_CLUBS.length));
      dials.heroLeagues = SYN_LEAGUES.slice(0, rnd(rng,1,SYN_LEAGUES.length));
      dials.multiPosP = rng()*0.6; dials.holdP = rng()*0.5; dials.premHeroP = rng();
      dials.minPer = 1; dials.maxPer = 4;
      break;
  }
  const f = pick(rng, dials.forms);
  let uid = 1; const cards = [];
  let natSeq = 0, clubSeq = 0;
  f.slots.forEach((pos, si) => {
    const n = rnd(rng, dials.minPer, dials.maxPer);
    for (let i = 0; i < n; i++) {
      const d = Object.assign({}, dials);
      if (regime === 'polyMax') { d.nations = ['N' + (natSeq++)]; d.clubs = ['C' + (clubSeq++)]; }
      const c = makeCard(uid++, rng, d);
      c.pos = [pos];
      if (rng() < dials.multiPosP) { const other = pick(rng, f.slots); if (other !== pos) c.pos.push(other); }
      cards.push(c);
    }
  });
  if (dials.holdP > 0) {
    const loose = cards.slice();
    let hid = 1;
    while (loose.length >= 2 && rng() < dials.holdP * 2) {
      const size = Math.min(rnd(rng, 2, 5), loose.length);
      const gid = 'G' + (hid++);
      for (let i = 0; i < size; i++) {
        const j = Math.floor(rng() * loose.length);
        loose[j].hold = gid; loose.splice(j, 1);
      }
    }
  }
  return { formName: f.name, form: { slots: f.slots.slice() }, cards, regime };
}

const REGIMES = ['ties','narrow','wide','monoNation','polyMax','iconHeavy','heroLeagues','holds','multiPos','dupSlots','kitchenSink'];

function generate(seed){
  const regime = REGIMES[seed % REGIMES.length];
  return genSynthetic(seed, regime);
}

module.exports = { generate, REGIMES, mulberry32, genSynthetic };
