'use strict';
// Extracted verbatim from the live <script> in index.html (auto-extracted dependency closure
// of scoreXI + solveBest + maxPossibleRating, via AST analysis on $(date)).

function futRatingRaw(rs){const S=rs.reduce((a,b)=>a+b,0),A=S/rs.length;let sp=0;for(const r of rs)if(r>A)sp+=r-A;return (S+sp)/rs.length;}

function leagueOf(c){return c.type==='icon'?'Icons':(c.league||'England Premier League')}

function trueChemPerCard(xi){
  const natCnt={},clubCnt={},lgCnt={};let icons=0;
  xi.forEach(c=>{
    if(c.type==='icon'){
      icons++;
      natCnt[c.nation]=(natCnt[c.nation]||0)+2;
    } else if(c.type==='hero'){
      natCnt[c.nation]=(natCnt[c.nation]||0)+1;
      const lg=leagueOf(c);
      lgCnt[lg]=(lgCnt[lg]||0)+2; // flat +2 per hero
    } else {
      natCnt[c.nation]=(natCnt[c.nation]||0)+1;
      clubCnt[c.club]=(clubCnt[c.club]||0)+1;
      const nlg=leagueOf(c);lgCnt[nlg]=(lgCnt[nlg]||0)+1; // v16.0.0: a normal counts toward ITS league, not an assumed-Prem bucket
    }
  });
  // v16.0.0: icons add +1 to EVERY league bucket present (generalized from the old
  // Prem-unconditional rule — identical numbers on an all-PL-normals DB because normals now
  // deposit into lgCnt[their real league] directly, see above, so PL's bucket already exists).
  if(icons>0){for(const lg of Object.keys(lgCnt))lgCnt[lg]+=icons;}
  const nP=n=>n>=8?3:n>=5?2:n>=2?1:0;
  const cP=n=>n>=7?3:n>=4?2:n>=2?1:0;
  const lP=n=>n>=8?3:n>=5?2:n>=3?1:0;
  return xi.map(c=>{
    if(c.type==='icon'||c.type==='hero')return 3;
    const lg=leagueOf(c);
    const lgScore=lP(lgCnt[lg]||0); // v16.0.0: one uniform rule — PL is just another league bucket now
    return Math.min(3,nP(natCnt[c.nation]||0)+cP(clubCnt[c.club]||0)+lgScore);
  });
}

function trueChem(xi){return trueChemPerCard(xi).reduce((a,b)=>a+b,0);}

function scoreXI(xi){
  const ratingExact=futRatingRaw(xi.map(c=>c.rating)),rating=Math.floor(ratingExact);
  const nations=new Set(xi.map(c=>c.nation)).size;
  const leagues=new Set(xi.map(leagueOf)).size;
  const premClubs=new Set(xi.filter(c=>c.type==='normal').map(c=>c.club)).size;
  const hasIcon=xi.some(c=>c.type==='icon'),hasHero=xi.some(c=>c.type==='hero');
  const clubs=premClubs+(hasIcon?1:0)+(hasHero?1:0);
  const glue=xi.filter(c=>c.type==='icon'||c.type==='normal').length;
  // v16.0.0: the full-chem shortcut generalizes from "Prem pool >= 8" to "BEST league pool >= 8":
  // per league L, pool(L) = normals of L (x1) + heroes of L (x2) + icons (wildcard +1 to every
  // league, mirroring trueChem). On an all-PL-normals pool max pool IS the old premPool, byte-identical.
  const _lgPool={};let _icons=0;
  xi.forEach(c=>{if(c.type==='icon'){_icons++;return;}const L=leagueOf(c);_lgPool[L]=(_lgPool[L]||0)+(c.type==='hero'?2:1);});
  let _bestPool=0;for(const L in _lgPool)if(_lgPool[L]>_bestPool)_bestPool=_lgPool[L];
  const premPool=_bestPool+_icons; // name kept for downstream readers; semantics: best-league pool
  // v16.1.3 BUGFIX (multi-league soundness): the check above only asked "does *some* league's pool
  // hit >=8", then applied chem=3 to EVERY card in the XI -- including normals whose OWN league is
  // a totally different, small bucket. That's unsound. trueChem's per-card cap
  // (Math.min(3, nP+cP+lgScore)) only auto-saturates at 3 via lgScore alone when the CARD'S OWN
  // league is the one that reached the threshold; a normal sitting in a mismatched singleton league
  // still needs its real nation+club+league math and can legitimately score 0 -- confirmed: a
  // 10-card single-league pivot XI + 1 mismatched normal was scoring full 33 here while trueChem()
  // on the identical XI returns 30 (the mismatched card actually contributes 0, not 3). Heroes/icons
  // are unconditionally 3 in trueChem regardless of league, so they never need this check -- only
  // normals do. Fix: the flat-3-everyone shortcut now requires EVERY normal to sit in a league whose
  // own pool already cleared 8 (there can be more than one such league); any other case falls
  // through to the real per-card trueChem() calc. On any all-PL-normals DB this is still exactly the
  // old behavior (one qualifying league, every normal is in it) -- byte-identical, per the
  // LEGACY EQUIVALENCE rule in section P.
  const _qualifyingLgs=new Set();for(const L in _lgPool)if(_lgPool[L]>=8)_qualifyingLgs.add(L);
  const _allNormalsQualify=xi.every(c=>c.type!=='normal'||_qualifyingLgs.has(leagueOf(c)));
  const full=(_qualifyingLgs.size>0&&_allNormalsQualify)||xi.every(c=>c.type==='icon'||c.type==='hero');
  const chem=full?3*xi.length:trueChem(xi);
  return {rating,ratingExact,chem,nations,leagues,clubs,full,glue,total:rating+chem+nations+leagues+clubs,
    nationSet:new Set(xi.map(c=>c.nation)),leagueSet:new Set(xi.map(leagueOf)),
    clubSet:new Set(xi.filter(c=>c.type==='normal').map(c=>c.club))};
}

function solveBest(form,cards,nodeCap,ratingCeil,seedBest,seedXIs,skipTies,diversitySeed,rootAllow){
  const ST=!!skipTies; // "Skip ties": prune branches that can only TIE the best (strict-improvement B&B) and stop collecting tied XIs. Provably keeps the optimal SCORE (never prunes a strictly-better branch, whose admissible bound must exceed best); only tied lineups are dropped.
  const RC=ratingCeil!==undefined?ratingCeil:99;
  const slots=form.slots;
  // v11.0 presort — rating-desc first as always (v5.1 best-first), but ties between EQUAL-rated
  // candidates are now broken by within-slot rarity: 1/(count of this nation in this slot's own
  // pool) + for normals 1/(count of this club in this slot's pool), weighted 0.4 each. Max nudge
  // 0.8 < 1, ratings are integers, so a lower-rated card can NEVER be tried before a higher-rated
  // one (verified over 20k random pools: 0 rating-order violations) — this is purely a tie-break.
  // Rationale: an equal-rated card that's the only one of its nation/club here banks a "free"
  // diversity point earlier, so capped searches sit on a better incumbent when cut off. Computed
  // ONCE per slot before the search (same cost class as the old sort); ordering only — candidates,
  // pruning, UB, and traversal structure are untouched, so any completed search returns the exact
  // same optimum as before (verified: identical best on every fixture; total node count identical
  // in 149/150 broad fuzz drafts). Where it earns its keep is CAPPED searches on huge drafts
  // (est. 10^8–10^12 combos, 10M-node cap, head-to-head on identical drafts): 56 hard trials —
  // 50 all-tied, and of the 6 divergences divstatic won 5 (+1 pt each) and lost 1 (seed 91041,
  // −2 pts). Also tested and REJECTED in the same campaign: (a) per-node dynamic re-sorting by
  // live path state (the removed v5.6 idea, re-tried at up to 150M nodes) — never beat this static
  // version on final score, 4–25% slower wall-time, reconfirming the v8.2 removal; (b) eight
  // isolated single-factor tie-breaks (position-flexibility both directions, nation/club/league
  // rarity alone, icon-first/normal-first type priority) — zero effect on total nodes in 120
  // broad trials each, and the only hard-trial divergence had club/league/icon-first variants
  // LOSING a point; the nation+club BLEND is the only ordering found to add anything.
  //
  // v12.0 DIVERSITY: when `diversitySeed` is a number, each slot's candidate list is instead
  // FULLY SHUFFLED (deterministically, from that seed) rather than divstatic-ordered. This throws
  // away best-first on purpose so the search walks a completely different region of the tree — used
  // only by the optional, default-off "search diversity" wrapper (solveWithDiversity below), which
  // spends part of the node budget on divstatic first (best incumbent) and the rest on one or more
  // seeded-shuffle passes, keeping whichever pass scored highest. As a FORCED default this is worse
  // (best-first ordering does real work — pure-shuffle lost to divstatic on ~65% of hard drafts),
  // but as an OPTIONAL alternate it strictly beat pure divstatic at equal budget on ~13% of hard
  // realistic drafts (+1 to +3 pts), symmetric high-variance — so it only ever helps here because
  // the wrapper keeps the max across passes, never the shuffle alone. Ordering-only, exactly like
  // the divstatic path: pruning/UB/traversal untouched, so a run that COMPLETES still returns the
  // true optimum regardless of seed. See the v12.0 CHANGELOG entry for the full experiment.
  const _divShuffle=(typeof diversitySeed==='number');
  let _dseed=(diversitySeed|0)||1;
  const _drand=()=>{_dseed|=0;_dseed=(_dseed+0x6D2B79F5)|0;let t=Math.imul(_dseed^(_dseed>>>15),1|_dseed);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};
  const cand=slots.map(s=>{
    const list=cards.filter(c=>c.pos.includes(s));
    if(_divShuffle){ // deterministic Fisher–Yates from the per-call seed (advances _dseed across slots)
      const a=list.slice();
      for(let i=a.length-1;i>0;i--){const j=Math.floor(_drand()*(i+1));const tmp=a[i];a[i]=a[j];a[j]=tmp;}
      return a;
    }
    const natCount={},clubCount={};
    for(const c of list){
      natCount[c.nation]=(natCount[c.nation]||0)+1;
      if(c.type==='normal')clubCount[c.club]=(clubCount[c.club]||0)+1;
    }
    return list.map(c=>({c,k:c.rating+0.4/(natCount[c.nation]||1)+(c.type==='normal'?0.4/(clubCount[c.club]||1):0)}))
      .sort((a,b)=>b.k-a.k).map(x=>x.c);
  });
  if(cand.some(l=>l.length===0))
    return {error:'A slot has no eligible card: '+slots.filter((s,i)=>cand[i].length===0).join(', ')};
  // v5.5 #2: cache _lg (leagueOf) and _group on every candidate once instead of recomputing in the hot loop
  for(const slot of cand)for(const c of slot){
    if(c._lg===undefined)c._lg=leagueOf(c);
    if(c._group===undefined)c._group=c.hold||('C'+c.id);
  }
  const order=slots.map((s,i)=>i).sort((a,b)=>cand[a].length-cand[b].length);
  // v14.0 (beta) — parallel-search partition hook: when rootAllow (a Set of card ids) is supplied,
  // the ROOT slot's candidate list is restricted to those cards. Used ONLY by _runSolveParallel to
  // split one huge search across Web Workers: each worker owns a disjoint share of the root
  // candidates, so the union of the workers' subtrees is exactly the full serial tree (every legal
  // XI has exactly one card in the root slot). Undefined -> byte-identical behavior to before.
  if(rootAllow){const _ri=order[0];cand[_ri]=cand[_ri].filter(c=>rootAllow.has(c.id));
    if(cand[_ri].length===0)return {best:(typeof seedBest==="number"&&seedBest>=0)?seedBest:-1,bestXIs:(seedXIs&&seedXIs.length)?seedXIs.slice():[],nodes:0,capped:false,slots,maxRating:-1,rcUsed:RC};}
  // v6 UB precompute — per remaining slot, the OLD bound assumed a flat "+2" for anything
  // that wasn't the one reserved "first icon"/"first hero" slot. That's safe (never an
  // underestimate) but loose whenever a slot's candidate pool is icon-only or hero-only —
  // e.g. a position where a user has stacked several icons and has no normal/hero card that
  // fits there. A 2nd+ icon can only ever add +1 (nation; "Icons" league + the icon club-
  // bonus are awarded once, to whichever icon comes first), so an icon-only slot's true max
  // is +1, not +2. This is computed ONCE per solveBest() call (static — resorting cand[] for
  // traversal order doesn't change which TYPES are present) as suffix aggregates, so the
  // per-node bound check below stays O(1), same as before.
  const slotTypes=cand.map(list=>{const s=new Set();for(const c of list)s.add(c.type);return s;});
  // v12.4.0: per-slot "every hero option here is a Prem-league hero" flag. A hero whose own
  // league IS 'England Premier League' doesn't add a fresh league the way a non-Prem hero does --
  // that league point is the same shared Prem bucket normals/premUnseen already cover globally,
  // earned once no matter how many Prem sources could supply it. So a slot whose only hero
  // candidates are Prem-league heroes can guarantee nation (+1) from that option, not nation+
  // league (+2) -- the old code credited +2 unconditionally, double-counting against premUnseen
  // in this one narrow case. See v12.4.0 CHANGELOG.
  const slotHeroAllPrem=cand.map(list=>{
    const heroes=list.filter(c=>c.type==='hero');
    return heroes.length>0&&heroes.every(c=>c.league==='England Premier League');
  });
  // v16.0.0 SOUNDNESS GATE (see sections F.1 + P): the v12.4.0 tightened baselines below encode
  // "Prem is one shared, premUnseen-covered league bucket". With real per-league normals in the
  // pool a normal can bring nation+club+A FRESH LEAGUE (+3 > the old b=2), and a "Prem-only-hero"
  // slot's league point is no longer globally shared — so the old tightenings can UNDER-count the
  // bound and silently prune optimal branches. When ANY non-PL normal is present we therefore
  // loosen to provably admissible baselines (normal=3, hero always=2); over-counting only slows
  // the search, never breaks optimality. All-PL pools (every pre-v16 DB) keep the tightened
  // bound byte-identical.
  const MULTI_LG=cards.some(c=>c.type==='normal'&&c.league&&c.league!=='England Premier League');
  const N=slots.length;
  const ubBaseline=new Array(N),ubSuffixBase=new Array(N+1).fill(0);
  const ubTopIconV=new Array(N+1),ubTopIconI=new Array(N+1),ubTopIconV2=new Array(N+1),ubTopIconI2=new Array(N+1);
  const ubTopHeroV=new Array(N+1),ubTopHeroI=new Array(N+1),ubTopHeroV2=new Array(N+1),ubTopHeroI2=new Array(N+1);
  ubTopIconV[N]=-Infinity;ubTopIconI[N]=-1;ubTopIconV2[N]=-Infinity;ubTopIconI2[N]=-1;
  ubTopHeroV[N]=-Infinity;ubTopHeroI[N]=-1;ubTopHeroV2[N]=-Infinity;ubTopHeroI2[N]=-1;
  for(let k=N-1;k>=0;k--){
    const idx=order[k];
    const st=slotTypes[idx];
    // v12.4.0: hero baseline is 2 (nation+own league) unless every hero option here is Prem-only,
    // in which case it's 1 (nation only -- the league point is the shared Prem bucket, not a
    // fresh per-slot one).
    const heroBase=(MULTI_LG||!slotHeroAllPrem[idx])?2:1; // v16.0.0: Prem-hero tightening only valid in the all-PL world
    let b=-Infinity;
    if(st.has('normal'))b=MULTI_LG?3:2; // v16.0.0: multi-league normal can bring nation+club+fresh league
    if(st.has('hero')&&b<heroBase)b=heroBase;
    if(st.has('icon')&&b<1)b=1;
    ubBaseline[k]=b;ubSuffixBase[k]=ubSuffixBase[k+1]+b;
    let iv=ubTopIconV[k+1],ii=ubTopIconI[k+1],iv2=ubTopIconV2[k+1],ii2=ubTopIconI2[k+1];
    if(st.has('icon')){const g=3-b;if(g>iv){iv2=iv;ii2=ii;iv=g;ii=k;}else if(g>iv2){iv2=g;ii2=k;}}
    ubTopIconV[k]=iv;ubTopIconI[k]=ii;ubTopIconV2[k]=iv2;ubTopIconI2[k]=ii2;
    // v12.4.0: the "first hero" bonus is always exactly +1 -- the one-time hero-club flag
    // (scoreXI's hasHero -> clubs+1) -- never 3-b. Previously b was always 2 for any hero-
    // possible slot, so 3-b always happened to come out to 1 anyway; now that Prem-exclusive
    // slots correctly get b=1, leaving this as 3-b would silently reinflate to 2, re-adding the
    // league point baseline just removed. Hardcoding the true, category-independent gain avoids
    // that regression and keeps every previously-existing case byte-identical (g was always 1
    // there too, just derived instead of stated).
    let hv=ubTopHeroV[k+1],hi=ubTopHeroI[k+1],hv2=ubTopHeroV2[k+1],hi2=ubTopHeroI2[k+1];
    if(st.has('hero')){const g=1;if(g>hv){hv2=hv;hi2=hi;hv=g;hi=k;}else if(g>hv2){hv2=g;hi2=k;}}
    ubTopHeroV[k]=hv;ubTopHeroI[k]=hi;ubTopHeroV2[k]=hv2;ubTopHeroI2[k]=hi2;
  }
  let best=(typeof seedBest==="number"&&seedBest>=0)?seedBest:-1;
  let bestXIs=(best>=0&&seedXIs&&seedXIs.length)?seedXIs.map(x=>({xi:x.xi,sc:x.sc,foundAt:0,seed:true})):[];
  // Highest TRUE squad rating (floor(ratingExact), the same integer that enters sc.total) seen across
  // every complete XI scored. RC only ever enters the search as the rating ceiling in the pruning UB
  // (ub = RC+33+chem/diversity); the score itself never clamps rating. So comparing this max to RC
  // tells the user whether RC was actually binding: max<RC means RC never touched a real squad (sound,
  // and RC could be lowered to save time); max===RC is the boundary (a higher-rated squad, if one
  // exists, would rate >RC and could have been pruned before we ever scored it); max>RC means the UB
  // underestimated at least one branch's rating, so better squads were likely pruned. One integer
  // compare per leaf — sc.rating is already computed for the score, so this adds no measurable cost.
  let maxRating=-1;
  if(bestXIs.length)for(const b of bestXIs){const rr=b.sc&&b.sc.rating;if(typeof rr==='number'&&rr>maxRating)maxRating=rr;}
  let nodes=0;const CAP=nodeCap||3000000;let capped=false;
  const usedGroups=new Set(),pick=new Array(slots.length).fill(null);
  // v5.5 #1: incremental diversity state — add on descent, delete on backtrack; eliminates
  // ~9M Set allocations at the 3M-node cap that the old per-node filter/map/Set pattern caused.
  const seenNat=new Set(),seenLg=new Set(),seenClub=new Set();
  let partialIcon=0,partialHero=0;
  const __dacV=[]; // v16.14.0: shared scratch vector for the DAC dynamic bound (reset per node)
  // v16.20.0 UB-SYM (slot symmetry, section T): two order-positions are STRUCTURALLY symmetric iff
  // same slot label AND identical STATIC candidate-object sets (computed once from cand[], never
  // history-dependent — the fact that sidesteps the eligible-set-snapshot problem the original idea-1
  // stub hit). Between such slots we enforce a canonical order (a later same-class slot's rating must
  // be <= the most recently committed member's), pruning redundant permutations of interchangeable
  // slots. SOUND: swapping which specific card two same-pool slots hold yields an identically-scored
  // completion using the same card set, so every canonical-order violation has an equal-scored
  // canonical twin reachable elsewhere in the tree — pruning it can only drop a duplicate, never the
  // optimum. Measured: fires on ~57% of drafts, node count ~20-24% of baseline, wall-time tracks it,
  // 0/1686 soundness mismatches across all 12 regimes. This is the first MULTIPLICATIVE win (skips k!
  // permutations of k interchangeable slots), not another additive per-node bound.
  const __symClassOf=(function(){
    const sigOf=slot=>cand[slot].map(c=>c._group).sort((a,b)=>a-b).join(','); // group ids: two prints of the same card share a group and are legitimately interchangeable
    const groups=new Map();
    for(let p=0;p<order.length;p++){const key=slots[order[p]]+'|'+sigOf(order[p]);let arr=groups.get(key);if(!arr){arr=[];groups.set(key,arr);}arr.push(p);}
    const classOf=new Array(order.length).fill(-1);let cid=0;
    for(const arr of groups.values()){if(arr.length<2)continue;for(const p of arr)classOf[p]=cid;cid++;}
    return classOf;
  })();
  const __symLastRating=new Map(); // classId -> rating most recently committed in this class on the current path (save/restore on backtrack)
  // v16.16.0 "H2-node": per-node analogue of the root's UB-H2 (see ubH2Bound/spMaxBoundPerSlot
  // above), re-adding DAC's collision-aware tightening WITHOUT its soundness trap. Instead of
  // building one N-length vector that some real completion has to dominate (the shape that broke
  // DAC), this bounds the exact max SUM over the R remaining slots via a small assignment (each
  // remaining slot gets at most one not-yet-used group, respecting exclusivity exactly -- no
  // guessing which slot "wins" a contested group) and separately bounds the max spread-above-mean
  // over each slot's own achievable [L,U] range intersected with that sum cap, then combines them
  // additively -- so no single vector has to dominate the true completion, and the UB-F/UB-G/DAC
  // counterexample (two legal completions whose rating vectors don't dominate each other) cannot
  // recur, because neither S_max nor sp_max relies on picking a winner between them; both are
  // exact maxima of two genuinely different, non-competing quantities.
  // Nested (not top-level) so solveBest.toString() still captures it whole for the Web Worker
  // parallel path (see _buildSolverWorkerBlob, which serializes solveBest by name only -- a new
  // top-level helper would NOT exist inside the worker and would throw).
  // COST/GATING: only invoked when the cheap __d check below does NOT already prune (paying the
  // assignment DP only on the harder nodes), and only for R<=8 remaining slots (always true here
  // since this whole section is gated k>=4, so R<=N-4<=7 for an 11-slot XI) -- vertex enumeration
  // is O(2^R + R*2^(R-1)) (<=576 evals at R=7); the assignment DP is O(groups * 2^R * R).
  // STATUS: sound by construction (argument above), but per this file's own F.2/Q.2 discipline this
  // is a fresh addition and has NOT yet been run through the full off-tree twelve-regime harness +
  // a DAC-style targeted collision generator -- run that before treating this as release-final.
  function assignMaxSumNode(remSlots,cand,usedGroups){
    const R=remSlots.length;
    const L=new Array(R),U=new Array(R);
    const groupBest=new Map(); // group -> Array(R) of its best rating for that remaining slot, or -Infinity
    for(let i=0;i<R;i++){
      const list=cand[remSlots[i]];let lo=Infinity,hi=-Infinity;
      for(const c of list){
        if(usedGroups.has(c._group))continue;
        if(c.rating>hi)hi=c.rating;
        if(c.rating<lo)lo=c.rating;
        let arr=groupBest.get(c._group);
        if(!arr){arr=new Array(R).fill(-Infinity);groupBest.set(c._group,arr);}
        if(c.rating>arr[i])arr[i]=c.rating;
      }
      if(hi===-Infinity)return null; // this slot has zero legal candidates -- no legal completion here
      L[i]=lo;U[i]=hi;
    }
    // Max-weight assignment of distinct groups to the R remaining slots, via bitmask DP over which
    // slots are filled so far (classic "one side small" assignment trick -- exact, not a relaxation,
    // and respects group exclusivity precisely instead of letting two slots double-claim one group).
    const full=(1<<R)-1;
    let dp=new Array(1<<R).fill(-Infinity);dp[0]=0;
    for(const arr of groupBest.values()){
      const next=dp.slice(); // read from the pre-this-group snapshot so each group is used at most once
      for(let mask=0;mask<=full;mask++){
        if(dp[mask]===-Infinity)continue;
        for(let i=0;i<R;i++){
          if(mask&(1<<i))continue;
          if(arr[i]===-Infinity)continue;
          const nm=mask|(1<<i),val=dp[mask]+arr[i];
          if(val>next[nm])next[nm]=val;
        }
      }
      dp=next;
    }
    const Smax=dp[full];
    if(Smax===-Infinity)return null; // no way to give every remaining slot a distinct group
    return {Smax,L,U};
  }
  // Exact max of sp(x)=sum(max(0,x_i-mean(x))) over the FULL N-length vector (k fixed committed
  // ratings + R free coords bounded by [L_i,U_i]) intersected with sum(free)<=freeCap, where sp is
  // convex so its max over this box-plus-hyperplane region is attained at a vertex with at most one
  // free coordinate not pinned to its own L/U -- same shape/argument as the root's
  // spMaxBoundPerSlot, just restricted to the R free dims with the k committed values held fixed.
  function spMaxFreeBox(fixedVals,L,U,SmaxTotal){
    const R=L.length,N=fixedVals.length+R,EPS=1e-9;
    const fixedSum=fixedVals.reduce((a,b)=>a+b,0),freeCap=SmaxTotal-fixedSum;
    function spOf(freeVals){
      const S=fixedSum+freeVals.reduce((a,b)=>a+b,0),A=S/N;let sp=0;
      for(const v of fixedVals)if(v>A)sp+=v-A;
      for(const v of freeVals)if(v>A)sp+=v-A;
      return sp;
    }
    let best=-Infinity;
    const total=1<<R;
    for(let mask=0;mask<total;mask++){
      const vals=new Array(R);let s=0;
      for(let i=0;i<R;i++){const v=(mask&(1<<i))?U[i]:L[i];vals[i]=v;s+=v;}
      if(s<=freeCap+EPS){const sp=spOf(vals);if(sp>best)best=sp;}
    }
    for(let flex=0;flex<R;flex++){
      const others=[];for(let i=0;i<R;i++)if(i!==flex)others.push(i);
      const M=others.length,subTotal=1<<M;
      for(let mask=0;mask<subTotal;mask++){
        const vals=new Array(R);let sumOthers=0;
        for(let mkk=0;mkk<M;mkk++){const i=others[mkk];const v=(mask&(1<<mkk))?U[i]:L[i];vals[i]=v;sumOthers+=v;}
        let v=freeCap-sumOthers;
        if(v<L[flex])v=L[flex];
        if(v>U[flex])v=U[flex];
        vals[flex]=v;
        const sp=spOf(vals);if(sp>best)best=sp;
      }
    }
    return best;
  }
  function h2NodeBound(k,order,cand,usedGroups,pick){
    const N=order.length,R=N-k;
    if(R<=1||R>8)return null; // trivial, or (defensively) too large to be cheap -- __d bound still applies
    const remSlots=new Array(R);for(let i=0;i<R;i++)remSlots[i]=order[k+i];
    const asn=assignMaxSumNode(remSlots,cand,usedGroups);
    if(!asn)return null;
    const committed=new Array(k);for(let j=0;j<k;j++)committed[j]=pick[order[j]].rating;
    const fixedSum=committed.reduce((a,b)=>a+b,0);
    const SmaxTotal=fixedSum+asn.Smax;
    const spMax=spMaxFreeBox(committed,asn.L,asn.U,SmaxTotal);
    return Math.floor((SmaxTotal+spMax)/N);
  }
  function dfs(k){
    let __rStar=-Infinity; // v16.14.0 UB-A: per-node minimal surviving candidate rating (set below)
    if(nodes++>CAP){capped=true;return;}
    if(capped)return;
    if(k===order.length){
      const xi=pick.slice(),sc=scoreXI(xi);
      if(sc.rating>maxRating)maxRating=sc.rating;   // cheap: sc.rating already computed for the score
      if(sc.total>best){best=sc.total;const key=xi.map(c=>c.id).sort().join(',');bestXIs=[{xi,sc,foundAt:nodes,key}]}
      else if(!ST && sc.total===best){
        const key=xi.map(c=>c.id).sort().join(',');
        if(!bestXIs.some(b=>(b.key||(b.key=b.xi.map(c=>c.id).sort().join(',')))===key))bestXIs.push({xi,sc,foundAt:nodes,key});
      }
      return;
    }
    const slotIdx=order[k];
    const __symCid=__symClassOf[k]; // v16.20.0 UB-SYM: this slot's symmetry class (-1 = none)
    const __symCeil=(__symCid>=0&&__symLastRating.has(__symCid))?__symLastRating.get(__symCid):Infinity; // canonical-order ceiling from the last-committed same-class member
    // v6 tighter UB — per remaining slot, use its ACTUAL candidate-type composition
    // (ubBaseline/ubSuffixBase, precomputed once above) instead of assuming every slot
    // can flex to +2. Baseline per slot (no "first icon/hero" bonus yet): normal=2
    // (nation+club), hero=2 (nation+own league), icon=1 (nation only — "Icons" league
    // and the icon club-bonus are only ever awarded once, to the first icon overall).
    // On top of the suffix's total baseline we optimally award the at-most-one remaining
    // "first icon" bonus (+2 over that slot's baseline) and at-most-one "first hero" bonus
    // (+1 over baseline) to whichever eligible slots gain the most — trying both assignment
    // orders (icon picks first vs hero picks first) since a slot able to take either bonus
    // can only be awarded one of them. Falls back to the old flat "+2 everywhere" bound
    // whenever every remaining slot also has a normal/hero option (the common case), so this
    // only bites — and only helps — when a position pool has gone icon/hero-only.
    // Verified against 20k+ randomized states + brute force: never below the true max,
    // and strictly tighter than the old bound in ~45% of those states.
    if(best>=0){
      const premUnseen=seenLg.has('England Premier League')?0:1;
      let total0=ubSuffixBase[k];
      // v16.14.0 UB-D (dynamic diversity caps): total0 statically credits each remaining slot its
      // max nat/lg/club gain, but the pool cannot deliver more NEW distinct values than it has
      // left: each cap = min(remaining slots, pool distinct - already seen). min() with the static
      // suffix is sound (both are valid upper credits) and bites hardest deep, where prunes decide.
      // (The v12.4.0 "diversity tightening never pays" verdict predates UB-R; with the rating term
      // now tight, this 1-4 pt slack is frequently the binding looseness. Measured in the UB-R4
      // harness: contributes on top of UB-A in every regime, O(1)/node.)
      {const __R=order.length-k;
       const __cN=Math.max(0,Math.min(__R,__PN-seenNat.size));
       const __cL=Math.max(0,Math.min(__R,__PL-seenLg.size));
       const __cC=Math.max(0,Math.min(__normTail[k],__PC-seenClub.size));
       const __alt=__cN+__cL+__cC;if(__alt<total0)total0=__alt;}
      let bonusGain;
      if(partialIcon&&partialHero){
        bonusGain=0;
      }else{
        const ic0v=partialIcon?0:(ubTopIconV[k]>0?ubTopIconV[k]:0),ic0i=partialIcon?-1:ubTopIconI[k];
        const he0v=partialHero?0:(ubTopHeroV[k]>0?ubTopHeroV[k]:0),he0i=partialHero?-1:ubTopHeroI[k];
        let orderA=ic0v; // icon takes its best slot first
        if(!partialHero){
          if(he0i!==ic0i)orderA+=he0v;
          else orderA+=(ubTopHeroV2[k]>0?ubTopHeroV2[k]:0);
        }
        let orderB=he0v; // hero takes its best slot first
        if(!partialIcon){
          if(ic0i!==he0i)orderB+=ic0v;
          else orderB+=(ubTopIconV2[k]>0?ubTopIconV2[k]:0);
        }
        bonusGain=Math.max(orderA,orderB);
      }
      const ub=RC+33
        +seenNat.size+seenLg.size+seenClub.size+partialIcon+partialHero
        +total0+bonusGain+premUnseen;
      if(ST?ub<=best:ub<best)return;
      // v16.13.3 UB-R (see FUTURE-MAINTAINERS section R): tighter admissible rating cap from THIS
      // path -- committed picks' real ratings + each remaining slot's max candidate rating (card
      // reuse/group exclusivity relaxed => never underestimates). futRatingRaw is per-component
      // monotone, so this dynRC >= any completion's true rating; min with RC keeps it no looser.
      // Gated k>=4 (near-root committed info too thin to pay for the O(11) vector build).
      //
      // v16.13.5 PROTOTYPE UB-R2 (see FUTURE-MAINTAINERS section R, "UB-R2" addendum): the plain
      // __slotMaxR lookup is stale -- precomputed ONCE before search starts, so it never looks at
      // usedGroups and can keep crediting a remaining slot with a card already consumed by a
      // committed pick (same shape of over-count UB-C fixed for the static root bound, here
      // showing up in the per-node vector instead). UB-R2 replaces it with a LIVE scan of each
      // remaining slot's (already ratings-desc-sorted) candidate list, taking the first candidate
      // whose group is NOT in usedGroups -- component-wise <= the old vector in every case, so it
      // is never looser, only tighter or equal (soundness proof + honest verdict in the section R
      // addendum). Fuzz-verified so far at "first pass" scale only (314 synthetic drafts, 0/314
      // soundness mismatches vs brute force, 0 cases worse than UB-R, 35 strictly better) -- NOT
      // yet run against the full off-tree twelve-regime harness + fingerprint fixtures per F.2/Q.2
      // discipline. THIS BLOCK IS SAFE TO REVERT if that harness ever turns up a mismatch: swap
      // the inner per-slot scan back to the single `__slotMaxR[order[__j]]` lookup (still computed
      // below, just unused for now, so reverting is a one-line change).
      if(best>=0&&k>=4){
        // v16.15.0 FIX (was "v16.14.0 UB-R4 DAC vector: UB-R2's live scan PLUS first-hit collision
        // fix"): the collision fix has been REVERTED. Targeted fuzzing built specifically for the
        // two-hold-group/two-position non-dominating shape (see FUTURE-MAINTAINERS section R,
        // UB-F/UB-G counterexample) found 11,340 soundness violations across 144,366 feasible
        // trials (~8.5%) -- the "DAC" collision resolution below arbitrarily picked a "winner" slot
        // for a group two remaining slots both cited as their live-best, and demoted the "loser" to
        // its own next-best. That is structurally the same move UB-F/UB-G made at the root and were
        // rejected for: when the two legal completions' true rating vectors don't dominate each
        // other ([100,85] vs [95,90]-style), guessing which slot the contested group actually lands
        // on can lock in the wrong guess, so the demoted slot's credited value can come in BELOW
        // what the real completion assigns it -- __d too low -> ub' too low -> a still-live branch
        // gets pruned. Reverted to the plain UB-R2 live scan: each remaining slot independently takes
        // its own first not-yet-used candidate, with NO cross-slot collision resolution, so two
        // slots may credit the same group's rating at once. That is a pure relaxation of group
        // exclusivity (same argument UB-A/UB-R/UB-R2 already rely on) and can only loosen the bound,
        // never tighten it past the true max -- sound by construction, and this exact scan was
        // fuzz-verified 0/314 before DAC's collision fix was layered on top in v16.14.0.
        // A CORRECT tightening (not implemented here -- needs its own from-scratch fuzz harness
        // before merge, per F.2/Q.2): an "H2-node" bound, the per-node analogue of the root's UB-H2.
        // Instead of building one vector that some completion must dominate, bound S_max (exact max
        // sum over the R remaining slots via a small max-weight bipartite matching / min-cost-flow,
        // since a raw sum has no domination trap) and sp_max (spread-above-mean, convex, so its max
        // over each slot's own [L,U] box intersected with sum<=S_max is attained at a box vertex --
        // cheap to enumerate for R<=7) INDEPENDENTLY, then combine (S_max+sp_max)/N. No single vector
        // has to dominate the true completion, so the UB-F/UB-G/DAC counterexample can't recur.
        __dacV.length=0;
        for(let __j=0;__j<order.length;__j++){
          if(__j<k){__dacV.push(pick[order[__j]].rating);continue;}
          const __slot=order[__j],__list=cand[__slot];let __m=0;
          for(let __i=0;__i<__list.length;__i++){const __c=__list[__i];if(!usedGroups.has(__c._group)){__m=__c.rating;break;}}
          __dacV.push(__m);
        }
        const __d=Math.floor(futRatingRaw(__dacV));
        if(__d<RC){const __u=ub-RC+__d;if(ST?__u<=best:__u<best)return;}
        // v16.16.1 DISABLED (see the v16.16.1 CHANGELOG entry above the <h1> for full data): the
        // v16.16.0 H2-node call that used to sit here is turned off, not deleted -- h2NodeBound()/
        // assignMaxSumNode()/spMaxFreeBox() below are still defined but now unreachable. A real DFS
        // branch-and-bound simulator (solver_bound_tests_v3.js, off-tree) measured h2NodeBound ALONE
        // visiting MORE nodes on average (424.4) than plain __d/r2Vec alone (99.2) across 800 real
        // search instances -- looser in the common case despite being exact per-node, because
        // maximizing S_max and sp_max INDEPENDENTLY (the fix that made it sound) costs more tightness
        // on typical drafts than it recovers on the rare contested-group nodes it targets. __d (plain
        // r2Vec) is once again the sole per-node pruning bound. DO NOT re-enable this call without
        // re-clearing the bar in that changelog entry (beat __d on BOTH node count AND wall-clock time
        // in a real DFS simulator, not just an isolated per-node soundness/tightness check).
        /* {const __h2=h2NodeBound(k,order,cand,usedGroups,pick);
         if(__h2!==null&&__h2<__d&&__h2<RC){
           const __u2=ub-RC+__h2;if(ST?__u2<=best:__u2<best)return;
         }} */
        // v16.14.0 UB-A (parent-side candidate rating threshold): reuse the vector just built.
        // For a candidate c at this slot, a sound envelope of its child's bound is
        // (ub-RC) + floor(futRatingRaw(vector with position k := c.rating)) -- the child's
        // remaining maxima can only be <= this vector's, and the parent's static part already
        // over-credits slot k. The envelope is monotone in c.rating, so binary-search the minimal
        // surviving rating ONCE, then skip lower-rated candidates with one compare in the loop
        // below, BEFORE paying recursion + set bookkeeping. Order-independent (a per-candidate
        // skip, not a break), so the v5.6 rejection of presorting is untouched. Biggest measured
        // UB-R4 win: ~5-6% fewer nodes at loose AND tight RC, 0 regressions in 400 drafts.
        {const __S0=ub-RC,__old=__dacV[k];
         const __D=(__r)=>{__dacV[k]=__r;const __dd=Math.floor(futRatingRaw(__dacV));return __dd<RC?__dd:RC;};
         const __pass=(__u2)=>!(ST?__u2<=best:__u2<best);
         if(!__pass(__S0+__D(__RMAX))){__dacV[k]=__old;return;} // no candidate at this slot can survive
         if(__pass(__S0+__D(__RMIN))){__rStar=-Infinity;}
         else{let __lo=__RMIN,__hi=__RMAX;
           while(__lo+1<__hi){const __mid=(__lo+__hi)>>1;if(__pass(__S0+__D(__mid)))__hi=__mid;else __lo=__mid;}
           __rStar=__hi;}
         __dacV[k]=__old;}
      } // ST: a branch that can only reach `best` is a tie we do not need
    }
    // v5.6 dynamic in-flight presort — reorders cand[slotIdx] using the *live* path state
    // (seenNat/seenLg/seenClub/partialIcon/partialHero) instead of the static rating-only
    // order computed once before the search began. A card's true value along THIS path is
    // rating + whatever NEW nation/league/club it would add right now; that marginal value
    // shifts every time a different sibling is picked higher up the tree, so resorting per
    // node keeps best-first traversal accurate as the search descends, not just at depth 0.
    // This is ordering only — every candidate already in cand[slotIdx] is still iterated and
    // the usedGroups skip + UB bound above are untouched, so no node is pruned that the static
    // order would have visited; we only change WHEN each sibling is tried, which lets `best`
    // converge faster and makes the existing UB cutoff bite earlier on capped searches.
    // Safe to sort in place: `order` is a fixed permutation computed once, so each depth k
    // owns exactly one slotIdx for the whole search — no other stack frame is ever mid-loop
    // over this same array, so resorting it here can't disturb a parent's in-progress iteration.
    // [v8.2 REMOVED: the v5.6 dynamic in-flight presort that lived here — a full comparator sort
    // (~10 Set.has per comparison) at EVERY node with >1 candidate. Measured head-to-head: optimum
    // identical on every fixture at every RC, capped-incumbent quality identical at 500k/3M caps on
    // the two hardest drafts, fingerprint 357,777 untouched — and removing it is 10-16% faster
    // wall-time across the board (nodes +1.8% on one fixture, each node far cheaper). The static
    // rating-order computed once before the search already finds the incumbent just as fast; the
    // endgame is bound-proving, which ordering cannot help. Same lesson as scarcity ordering and
    // the suffix resource caps: per-node cleverness must be measured, and it keeps losing.]
    for(const c of cand[slotIdx]){
      if(c.rating<__rStar)continue; // v16.14.0 UB-A: provably-pruned child, skipped pre-recursion
      if(c.rating>__symCeil)continue; // v16.20.0 UB-SYM: canonical-order break — a later same-class slot may not out-rate an earlier one (redundant permutation, safe to skip)
      const g=c._group;
      if(usedGroups.has(g))continue;
      usedGroups.add(g);pick[slotIdx]=c;
      // Incremental updates (O(1) each)
      const addNat=seenNat.has(c.nation)?0:(seenNat.add(c.nation),1);
      const addLg =seenLg.has(c._lg)   ?0:(seenLg.add(c._lg),1);
      const addClub=c.type==='normal'&&!seenClub.has(c.club)?(seenClub.add(c.club),1):0;
      const addIcon=!partialIcon&&c.type==='icon'?1:0;if(addIcon)partialIcon=1;
      const addHero=!partialHero&&c.type==='hero'?1:0;if(addHero)partialHero=1;
      const __symPrev=__symCid>=0?(__symLastRating.has(__symCid)?__symLastRating.get(__symCid):null):null;
      if(__symCid>=0)__symLastRating.set(__symCid,c.rating);
      dfs(k+1);
      // Backtrack (O(1) each)
      if(__symCid>=0){if(__symPrev===null)__symLastRating.delete(__symCid);else __symLastRating.set(__symCid,__symPrev);}
      if(addNat) seenNat.delete(c.nation);
      if(addLg)  seenLg.delete(c._lg);
      if(addClub)seenClub.delete(c.club);
      if(addIcon)partialIcon=0;
      if(addHero)partialHero=0;
      usedGroups.delete(g);pick[slotIdx]=null;
      if(capped)return;
    }
  }
  // v16.13.3 UB-R: per-slot max candidate rating, for the per-node dynamic rating cap in dfs()
  // v16.13.5: no longer READ by the live UB-R2 scan above (kept computed so a revert to plain
  // UB-R, if the full harness later turns up an unsoundness, is a one-line change back).
  const __slotMaxR=cand.map(l=>l.length?Math.max.apply(null,l.map(c=>c.rating)):0);
  // v16.14.0 UB-R4 "DAC" precompute (section R addendum): pool distinct counts for the dynamic
  // diversity caps (UB-D), remaining-normal-capable suffix (club cap), and the pool rating range
  // for the parent-side candidate threshold search (UB-A).
  const __PN=new Set(cards.map(c=>c.nation)).size;
  const __PL=new Set(cards.map(c=>leagueOf(c))).size;
  const __PC=new Set(cards.filter(c=>c.type==='normal').map(c=>c.club)).size;
  const __normTail=new Array(order.length+1).fill(0);
  for(let __j=order.length-1;__j>=0;__j--)__normTail[__j]=__normTail[__j+1]+(cand[order[__j]].some(c=>c.type==='normal')?1:0);
  let __RMIN=Infinity,__RMAX=-Infinity;for(const c of cards){if(c.rating<__RMIN)__RMIN=c.rating;if(c.rating>__RMAX)__RMAX=c.rating;}
  dfs(0);
  return {best,bestXIs,nodes,capped,slots,maxRating,rcUsed:RC};
}

function ubDComponent(candList, positions, need){
  const groupOf=c=>c.hold||('C'+c.id);
  const groups={};
  for(const c of candList){
    const g=groupOf(c);
    if(!groups[g]) groups[g]={eligPos:new Set(), bestRating:-Infinity};
    for(const p of c.pos){
      if(positions.includes(p)){
        groups[g].eligPos.add(p);
        if(c.rating>groups[g].bestRating) groups[g].bestRating=c.rating;
      }
    }
  }
  const groupIds=Object.keys(groups)
    .filter(g=>groups[g].eligPos.size>0)
    .sort((a,b)=>groups[b].bestRating-groups[a].bestRating); // greedy processes highest weight first

  const posAssignments={}; for(const p of positions) posAssignments[p]=[];

  // Kuhn's-algorithm augmenting-path search: try to place `gid`, bumping/re-routing an existing
  // occupant to a different eligible position if that's what it takes to make room.
  function tryAugment(gid, visitedPos){
    for(const p of groups[gid].eligPos){
      if(visitedPos.has(p)) continue;
      visitedPos.add(p);
      if(posAssignments[p].length<need[p]){
        posAssignments[p].push(gid);
        return true;
      }
      for(let k=0;k<posAssignments[p].length;k++){
        const other=posAssignments[p][k];
        if(tryAugment(other, visitedPos)){
          posAssignments[p][k]=gid;
          return true;
        }
      }
    }
    return false;
  }

  const K=positions.reduce((s,p)=>s+need[p],0);
  const chosen=[];
  let matched=0;
  for(const gid of groupIds){
    if(tryAugment(gid, new Set())){
      matched++;
      chosen.push(groups[gid].bestRating);
      if(matched===K) break;
    }
  }
  if(matched<K) return {feasible:false};
  return {feasible:true, chosen};
}

function ubEGlobal(elig, slots, need){
  const groupOf=c=>c.hold||('C'+c.id);
  const positions=Object.keys(need);
  const groups={};
  for(const c of elig){
    const g=groupOf(c);
    if(!groups[g]) groups[g]={eligPos:new Set(), bestRating:-Infinity};
    for(const p of c.pos){
      if(need[p]!==undefined){
        groups[g].eligPos.add(p);
        if(c.rating>groups[g].bestRating) groups[g].bestRating=c.rating;
      }
    }
  }
  const groupIds=Object.keys(groups)
    .filter(g=>groups[g].eligPos.size>0)
    .sort((a,b)=>groups[b].bestRating-groups[a].bestRating);

  const posAssignments={}; for(const p of positions) posAssignments[p]=[];
  function tryAugment(gid, visitedPos){
    for(const p of groups[gid].eligPos){
      if(visitedPos.has(p)) continue;
      visitedPos.add(p);
      if(posAssignments[p].length<need[p]){
        posAssignments[p].push(gid);
        return true;
      }
      for(let k=0;k<posAssignments[p].length;k++){
        const other=posAssignments[p][k];
        if(tryAugment(other, visitedPos)){
          posAssignments[p][k]=gid;
          return true;
        }
      }
    }
    return false;
  }

  const N=slots.length;
  const chosen=[];
  let matched=0;
  for(const gid of groupIds){
    if(tryAugment(gid, new Set())){
      matched++;
      chosen.push(groups[gid].bestRating);
      if(matched===N) break;
    }
  }
  if(matched<N) return {feasible:false};
  return {feasible:true, chosen};
}

function minCostMaxFlow(numNodes, source, sink, edges, targetFlow){
  const graph = Array.from({length:numNodes}, ()=>[]);
  const edgeList = [];
  function addEdge(u,v,cap,cost){
    edgeList.push({u,v,cap,cost,flow:0});
    edgeList.push({u:v,v:u,cap:0,cost:-cost,flow:0});
    graph[u].push(edgeList.length-2);
    graph[v].push(edgeList.length-1);
  }
  for(const e of edges) addEdge(e.u,e.v,e.cap,e.cost);

  let totalFlow=0, totalCost=0;
  while(totalFlow<targetFlow){
    const dist = new Array(numNodes).fill(Infinity);
    const inQueue = new Array(numNodes).fill(false);
    const prevEdge = new Array(numNodes).fill(-1);
    dist[source]=0;
    const queue=[source]; inQueue[source]=true;
    let head=0, iterations=0;
    const maxIter = numNodes*numNodes*4+50;
    while(head<queue.length && iterations<maxIter){
      iterations++;
      const u=queue[head++]; inQueue[u]=false;
      for(const ei of graph[u]){
        const e=edgeList[ei];
        if(e.cap-e.flow<=0) continue;
        if(dist[u]+e.cost < dist[e.v]-1e-9){
          dist[e.v]=dist[u]+e.cost;
          prevEdge[e.v]=ei;
          if(!inQueue[e.v]){ queue.push(e.v); inQueue[e.v]=true; }
        }
      }
    }
    if(dist[sink]===Infinity) break; // no more augmenting paths
    let bottleneck=targetFlow-totalFlow;
    let v=sink;
    while(v!==source){
      const ei=prevEdge[v];
      const e=edgeList[ei];
      bottleneck=Math.min(bottleneck, e.cap-e.flow);
      v=e.u;
    }
    v=sink;
    while(v!==source){
      const ei=prevEdge[v];
      edgeList[ei].flow+=bottleneck;
      edgeList[ei^1].flow-=bottleneck;
      totalCost += edgeList[ei].cost*bottleneck;
      v=edgeList[ei].u;
    }
    totalFlow+=bottleneck;
  }
  return {flow:totalFlow, cost:totalCost};
}

function spMaxBoundPerSlot(bounds, Smax){
  const N = bounds.length;
  const EPS = 1e-9;
  function spOf(vals){
    const S=vals.reduce((a,b)=>a+b,0), A=S/vals.length;
    let sp=0; for(const v of vals) if(v>A) sp+=v-A;
    return sp;
  }
  let best = -Infinity;

  const total = 1<<N;
  for(let mask=0; mask<total; mask++){
    const vals = new Array(N);
    let s = 0;
    for(let i=0;i<N;i++){
      const v = (mask & (1<<i)) ? bounds[i].U : bounds[i].L;
      vals[i] = v; s += v;
    }
    if(s <= Smax + EPS){
      const sp = spOf(vals);
      if(sp > best) best = sp;
    }
  }

  for(let flex=0; flex<N; flex++){
    const others = [];
    for(let i=0;i<N;i++) if(i!==flex) others.push(i);
    const M = others.length;
    const subTotal = 1<<M;
    for(let mask=0; mask<subTotal; mask++){
      const vals = new Array(N);
      let sumOthers = 0;
      for(let k=0;k<M;k++){
        const i = others[k];
        const v = (mask & (1<<k)) ? bounds[i].U : bounds[i].L;
        vals[i] = v; sumOthers += v;
      }
      let v = Smax - sumOthers;
      if(v < bounds[flex].L) v = bounds[flex].L;
      if(v > bounds[flex].U) v = bounds[flex].U;
      vals[flex] = v;
      const sp = spOf(vals);
      if(sp > best) best = sp;
    }
  }
  return best;
}

function ubH2Bound(elig, slots, need){
  const N = slots.length;
  const positions = Object.keys(need);
  const groupOf = c=>c.hold||('C'+c.id);

  const posBest={};
  const posLmin={}, posUmax={};
  for(const c of elig){
    const g=groupOf(c);
    if(!posBest[g]) posBest[g]={};
    for(const p of c.pos){
      if(need[p]!==undefined){
        if(posBest[g][p]===undefined || c.rating>posBest[g][p]) posBest[g][p]=c.rating;
        if(posLmin[p]===undefined || c.rating<posLmin[p]) posLmin[p]=c.rating;
        if(posUmax[p]===undefined || c.rating>posUmax[p]) posUmax[p]=c.rating;
      }
    }
  }
  const groupIds=Object.keys(posBest);

  const G=groupIds.length, P=positions.length;
  const SOURCE=0, groupBase=1, posBase=1+G, SINK=1+G+P;
  const numNodes=SINK+1;
  const edges=[];
  for(let gi=0; gi<G; gi++) edges.push({u:SOURCE, v:groupBase+gi, cap:1, cost:0});
  for(let gi=0; gi<G; gi++){
    const g=groupIds[gi];
    for(let pi=0; pi<P; pi++){
      const p=positions[pi];
      if(posBest[g][p]!==undefined) edges.push({u:groupBase+gi, v:posBase+pi, cap:1, cost:-posBest[g][p]});
    }
  }
  for(let pi=0; pi<P; pi++) edges.push({u:posBase+pi, v:SINK, cap:need[positions[pi]], cost:0});

  const {flow, cost} = minCostMaxFlow(numNodes, SOURCE, SINK, edges, N);
  if(flow<N) return null;

  const Smax = -cost;
  const bounds = slots.map(p => ({L: posLmin[p], U: posUmax[p]}));
  const spMax = spMaxBoundPerSlot(bounds, Smax);
  return (Smax + spMax)/N;
}

function maxPossibleRating(pool,form){
  if(!pool||!pool.length||!form)return null;
  const slots=form.slots,slotSet=new Set(slots),N=slots.length;
  const groupOf=c=>c.hold||('C'+c.id);
  const elig=pool.filter(c=>c.pos&&c.pos.some(p=>slotSet.has(p))); // a card that fits no slot can never be in an XI
  const ubs=[];
  // UB-A: hold-collapsed, position-relaxed top-11
  {
    const byGroup={};
    for(const c of elig){const g=groupOf(c);if(byGroup[g]===undefined||c.rating>byGroup[g])byGroup[g]=c.rating;}
    const rs=Object.keys(byGroup).map(k=>byGroup[k]).sort((a,b)=>b-a);
    if(rs.length>=N)ubs.push(futRatingRaw(rs.slice(0,N)));
  }
  // UB-B: per-position head-count, hold-distinct within the position
  {
    const need={};for(const s of slots)need[s]=(need[s]||0)+1;
    const chosen=[];let feasible=true;
    for(const pos in need){
      const k=need[pos];
      const cand=elig.filter(c=>c.pos.includes(pos)).sort((a,b)=>b.rating-a.rating);
      const seen=new Set(),top=[];
      for(const c of cand){const g=groupOf(c);if(seen.has(g))continue;seen.add(g);top.push(c.rating);if(top.length===k)break;}
      if(top.length<k){feasible=false;break;} // too few distinct-hold cards for this position -> skip method
      for(const r of top)chosen.push(r);
    }
    if(feasible&&chosen.length===N)ubs.push(futRatingRaw(chosen));
  }
  // UB-C: position-adjacency components — union any two formation positions that share a real
  // eligible card in the pool (transitively, via union-find), then treat each resulting component
  // as ONE shared hold-distinct bucket (headcount = sum of its positions' needs). An LB/LM/LW card
  // unions those three positions into one bucket and can only be picked ONCE within it, fixing
  // UB-B's per-position double-count for versatile cards, while GK (which normally shares no
  // eligible card with any outfield position) still splits into its own singleton component instead
  // of "borrowing" bound from a stacked outfield position the way UB-A's single global bucket does.
  {
    const need={};for(const s of slots)need[s]=(need[s]||0)+1;
    const posArr=Object.keys(need);
    const parent={};posArr.forEach(p=>parent[p]=p);
    const find=x=>{while(parent[x]!==x){parent[x]=parent[parent[x]];x=parent[x];}return x;};
    const union=(a,b)=>{const ra=find(a),rb=find(b);if(ra!==rb)parent[ra]=rb;};
    for(const c of elig){
      const rel=c.pos.filter(p=>need[p]!==undefined); // this card's positions that are actually needed by the formation
      for(let i=1;i<rel.length;i++)union(rel[0],rel[i]); // any card eligible for 2+ needed positions links them into one component
    }
    const comps={};
    for(const p of posArr){const r=find(p);(comps[r]=comps[r]||[]).push(p);}
    let feasible=true;const chosen=[];
    for(const r in comps){
      const compPos=new Set(comps[r]);
      const k=comps[r].reduce((s,p)=>s+need[p],0);
      const cand=elig.filter(c=>c.pos.some(p=>compPos.has(p))).sort((a,b)=>b.rating-a.rating);
      const seen=new Set(),top=[];
      for(const c of cand){const g=groupOf(c);if(seen.has(g))continue;seen.add(g);top.push(c.rating);if(top.length===k)break;}
      if(top.length<k){feasible=false;break;} // too few distinct-hold cards for this component -> skip method
      for(const rr of top)chosen.push(rr);
    }
    if(feasible&&chosen.length===N)ubs.push(futRatingRaw(chosen));
  }
  // UB-D: same components as UB-C, but each component's exact per-position capacity is verified
  // via matroid-greedy + augmenting-path placement instead of UB-C's "aggregate headcount only"
  // check — never looser than UB-C, sometimes strictly tighter. See ubDComponent() and the long
  // comment above this function for why this must NOT be a sum-maximising matching.
  {
    const need={};for(const s of slots)need[s]=(need[s]||0)+1;
    const posArr=Object.keys(need);
    const parent={};posArr.forEach(p=>parent[p]=p);
    const find=x=>{while(parent[x]!==x){parent[x]=parent[parent[x]];x=parent[x];}return x;};
    const union=(a,b)=>{const ra=find(a),rb=find(b);if(ra!==rb)parent[ra]=rb;};
    for(const c of elig){
      const rel=c.pos.filter(p=>need[p]!==undefined);
      for(let i=1;i<rel.length;i++)union(rel[0],rel[i]);
    }
    const comps={};
    for(const p of posArr){const r=find(p);(comps[r]=comps[r]||[]).push(p);}
    let feasible=true;const chosen=[];
    for(const r in comps){
      const compPos=new Set(comps[r]);
      const candList=elig.filter(c=>c.pos.some(p=>compPos.has(p)));
      const result=ubDComponent(candList, comps[r], need);
      if(!result.feasible){feasible=false;break;}
      for(const rr of result.chosen)chosen.push(rr);
    }
    if(feasible&&chosen.length===N)ubs.push(futRatingRaw(chosen));
  }
  // UB-E: same matroid-greedy + augmenting-path placement as UB-D, but as ONE global problem over
  // every eligible position in the formation instead of splitting into components first — a
  // hold-group can only be placed (and credited) once overall, closing UB-D's narrower "once per
  // component" leak. Independently valid, but does NOT dominate UB-D (corrected v10.3.0.1 — neither
  // method dominates the other; kept side by side in the min() on equal footing). See ubEGlobal()
  // and the long "UB-E" comment above this function for the full argument and counterexample.
  {
    const need={};for(const s of slots)need[s]=(need[s]||0)+1;
    const result=ubEGlobal(elig, slots, need);
    if(result.feasible && result.chosen.length===N)ubs.push(futRatingRaw(result.chosen));
  }
  // UB-H2: a genuinely different relaxation from A-E's matroid-greedy-domination family (see the
  // v10.3 CHANGELOG entry and the "UB-H2 helper" comments above ubH2Bound() for the full
  // soundness argument) — bounds futRatingRaw's sum and spread-above-mean terms SEPARATELY
  // instead of building one credited vector and hoping it dominates the true winner, so it isn't
  // subject to the UB-F/UB-G counterexample. Never proven to dominate A-E in every case (or vice
  // versa), so it's combined via min() rather than replacing them.
  {
    const need={};for(const s of slots)need[s]=(need[s]||0)+1;
    const h2=ubH2Bound(elig, slots, need);
    if(h2!==null)ubs.push(h2);
  }
  if(!ubs.length)return null;
  return Math.floor(Math.min(...ubs)); // min of valid upper bounds is still valid, and tightest
}

module.exports = { scoreXI, solveBest, maxPossibleRating };
