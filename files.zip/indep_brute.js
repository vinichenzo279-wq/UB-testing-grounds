'use strict';
function bruteForce(form, cards, scoreXI, opts){
  opts = opts || {};
  const nodeCap = opts.leafCap !== undefined ? opts.leafCap : Infinity;
  const deadline = opts.timeBudgetMs ? Date.now() + opts.timeBudgetMs : Infinity;
  const slots = form.slots;
  const N = slots.length;
  const cand = [];
  for (let s = 0; s < N; s++) {
    const list = [];
    for (let i = 0; i < cards.length; i++) {
      if (cards[i].pos.indexOf(slots[s]) !== -1) list.push(i);
    }
    if (list.length === 0) return { best: -1, bestXI: null, leaves: 0, complete: true, infeasible: true };
    cand.push(list);
  }
  const groupOf = cards.map(c => (c.hold !== null && c.hold !== undefined) ? ('H:' + c.hold) : ('S:' + c.id));
  const idx = new Array(N).fill(0);
  const chosen = new Array(N);
  let best = -1, bestXI = null, leaves = 0, checked = 0;
  let complete = true;
  outer:
  while (true) {
    checked++;
    if (checked > nodeCap) { complete = false; break; }
    if ((checked & 8191) === 0 && Date.now() > deadline) { complete = false; break; }
    let legal = true;
    const seen = Object.create(null);
    for (let s = 0; s < N; s++) {
      const ci = cand[s][idx[s]];
      chosen[s] = ci;
      const g = groupOf[ci];
      if (seen[g]) { legal = false; break; }
      seen[g] = true;
    }
    if (legal) {
      leaves++;
      const xi = chosen.map(ci => cards[ci]);
      const sc = scoreXI(xi);
      if (sc.total > best) { best = sc.total; bestXI = xi.slice(); }
    }
    let s = N - 1;
    while (s >= 0) {
      idx[s]++;
      if (idx[s] < cand[s].length) continue outer;
      idx[s] = 0;
      s--;
    }
    break;
  }
  return { best, bestXI, leaves, checked, complete, infeasible: false };
}
function estimateCombos(form, cards) {
  let prod = 1;
  for (const s of form.slots) {
    let n = 0;
    for (const c of cards) if (c.pos.indexOf(s) !== -1) n++;
    if (n === 0) return 0;
    prod *= n;
    if (prod > 1e15) return prod;
  }
  return prod;
}
module.exports = { bruteForce, estimateCombos };
